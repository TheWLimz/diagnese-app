package com.diagnese.app.core.domain.data

data class User(
    val name : String,
    val email : String,
    val age : Int,
    val gender : String
)
