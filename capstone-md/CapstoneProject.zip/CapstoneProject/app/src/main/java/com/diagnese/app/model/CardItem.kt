package com.diagnese.app.model

data class CardItem(
    val image : Int,
    val title : String,
    val slug : String,
    val buttonMenu : String
)
